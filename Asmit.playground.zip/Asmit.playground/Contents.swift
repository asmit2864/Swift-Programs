import UIKit

// IF ELSE

//var a:Int = 3
//var b = 3
//var c = 4
//if a>b && a>c {
//    print("a is greater than c and b")
//}
//else if b>c && b>a {
//    print("b is greater than a and c")
//}
//else {
//    print("c is greater than a and b")
//}



// SWITCH CASE
//
//var n = 4
//
//switch n {
//case 1 :
//    print("one")
//case 2 :
//    print("two")
//case 3 :
//    print("three")
//default:
//    print("Other")
//}
//
//var x = "Asmit"
//
//switch x {
//case "Asmit" :
//    print("one")
//case "Adfg" :
//    print("two")
//case "hung" :
//    print("three")
//default:
//    print("Other")
//}

//var 😃 = "Asmit"
//
//switch 😃 {
//case "Asmit" :
//    print("one")
//case "Adfg" :
//    print("two")
//case "hung" :
//    print("three")
//default:
//    print("Other")
//}


// LOOPS

// WHILE LOOP

//var x=4
//while x>=0 {
//    print(x)
//    x-=1
//}

// REPEAT WHILE LOOP

//var x=4
//repeat{
//    print(x)
//    x-=1
//}while x>=0

// FOR LOOP

//for i in 1...10 {
//    print(i)
//}

//for i in stride(from:1,to:10,by:2) {
//    print(i)
//}

//let arr = [1,2,3,4,5]
//for i in arr {
//    print(i)
//}

//for i in 0...4 {
//    print(arr[i])
//}


// RESULT OF A STUDENT

//var marks = [23,34,21,54,67];
//var totalMarks = 100;
//var status = false
//for i in marks {
//    if i < 33 {
//        status = true
//    }
//}
//if (status) {
//    print("Student is passed")
//}
//else {
//    print("Student is failed")
//}



// REVERSE A NUMBER

//var num = 23
//var rev = 0;
//while(num>0){
//    rev = rev*10 + num%10;
//    num/=10;
//}
//print(rev)



// FUNCTIONS AND ARRAYS

//func sum (x:[Int]) -> Int {
//    var s = 0;
//    for i in x {
//        s += i;
//    }
//    return s
//}
//
//var arr:[Int] = [1,2,3,4,5]
//print(sum(x:arr))

//func show() -> (Int,Bool) {
//    return (3,false)
//}
//
//var (a,b) = show()
//print(a,b)


// FUNCTION OVERLOADING

//func show(n:String) -> String {
//    return n
//}
//func show(m:String) -> String {
//    return m;
//}
//
//print(show(n:"Asmit"))
//print(show(m:"Kumar"))


//var a = "Asmit";
//print(a.count)
//for i in a { print(i) }


// MAJORITY ELEMENT
//var arr = [1,2,3,3,4,3,2,2,2,2,1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,3,2];
//var n = arr.count;
//
//var ele = 0;
//var cnt = 0;
//
//for i in 0..<n {
//    if cnt == 0 {
//        ele = arr[i]
//        cnt+=1
//    }
//    else if ele == arr[i] {
//        cnt+=1
//    }
//    else {
//        cnt-=1
//    }
//}
//
//var count = 0;
//for i in arr {
//    if(ele == i) {
//        count+=1;
//    }
//}
//var ans = -1;
//if(count>n/2) {
//    ans = ele;
//}
//print(ans)



//func factorial(n:Float) -> Float {
//    if(n == 0 || n==1){
//        return n;
//    }
//    return n * factorial(n:n-1);
//}
//
//print(factorial(n:25))


//func fibo(n:Int) -> Int{
//    if(n==0 || n==1) {
//        return n;
//    }
//    return fibo(n:n-1) + fibo(n:n-2);
//}
//print(fibo(n:4))


// CLOSURES

//var show = {
//    print("Asmit")
//}
//show()
//
//
//
//var show1 = {
//    () in
//    print("Asmit")
//}
//show1()
//
//
//
//var show2 = {
//    () -> Void in
//    print("Asmit")
//}
//show2()
//// or
//var shows2 : () -> Void = {
//    print("ASmit")
//}
//shows2()
//// or
//var showss2 : () -> Void = {
//    () in
//    print("ASmit")
//}
//showss2()
//
//
//
//var show3 = {
//    (name:String) in
//    print(name)
//}
//show3("Asmit")
//
//
//
//var show4 = {
//    (a:Int,b:Int) -> Int in
//    return a+b
//}
//print(show4(3,4))
////or
//var shows4 : (Int,Int) -> Int = {
//    (a,b) in return a+b
//}
//print(shows4(3,2))



// TRAILING CLOSURES

//func maths (a:Int, b:Int, sum:(Int,Int) -> Int) {
//    let s = sum(a,b);
//    print(s)
//}
//
//maths(a:2,b:3){(x,y) in return x+y}
//maths(a:3,b:4){(x,y) in return x-y}
//maths(a:2,b:5){(x,y) in return x*y}




// DICTIONARY

//// creating dictionary
//let fruits = [1:"Apple", 2:"Mango", 3:"Guava"]
//let veg:[Int:String] = [1:"BottleGuard", 2:"Karela"]
//let emptyList:[Int:String] = [:]
//
//// accessing elements
//print(fruits[1])
//print(veg[2]);
//print(emptyList)
//
//// adding elements
//var dict = [1:"force", 2:"Rampage"]
//dict[3] = "Western"
//
//// updating elements
//dict[1] = "Forcing"
//
//// Accessing all keys
//var keys = Array(dict.keys);
//print(keys);
//
//// Accessing all values
//var values =  Array(dict.values)
//
//// remove a value
//dict.removeValue(forKey: 2)
//

